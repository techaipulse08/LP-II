import java.util.*;

class AStarGrid {

    // Node represents each cell in the grid with cost and parent reference
    static class Node {
        int row, col;     // Coordinates of the node
        int g, h;         // g = cost from start, h = estimated cost to end
        Node parent;      // To reconstruct path

        Node(int row, int col, int g, int h, Node parent) {
            this.row = row; this.col = col;
            this.g = g; this.h = h;
            this.parent = parent;
        }

        int f() { return g + h; } // f = total cost
    }

    // Possible directions: Right, Down, Left, Up
    static int[][] directions = {{0,1},{1,0},{0,-1},{-1,0}};

    // A* algorithm function
    public static List<int[]> aStar(int[][] grid, int[] start, int[] end) {
        int rows = grid.length, cols = grid[0].length;
        boolean[][] visited = new boolean[rows][cols]; // Tracks visited nodes

        // Priority queue ordered by f = g + h (lowest first)
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingInt(Node::f));
        open.add(new Node(start[0], start[1], 0, heuristic(start, end), null)); // Start node

        while (!open.isEmpty()) {
            Node current = open.poll(); // Get node with lowest f

            // If goal reached, reconstruct and return path
            if (current.row == end[0] && current.col == end[1])
                return reconstructPath(current);

            visited[current.row][current.col] = true;

            // Explore neighbors
            for (int[] dir : directions) {
                int r = current.row + dir[0], c = current.col + dir[1];

                // Check boundaries and obstacles
                if (r >= 0 && r < rows && c >= 0 && c < cols &&
                    grid[r][c] == 0 && !visited[r][c]) {

                    // Add neighbor node to open list
                    open.add(new Node(r, c, current.g + 1, heuristic(new int[]{r, c}, end), current));
                }
            }
        }
        return Collections.emptyList(); // No path found
    }

    // Heuristic function using Manhattan distance
    static int heuristic(int[] a, int[] b) {
        return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]);
    }

    // Reconstructs the path from goal to start using parent references
    static List<int[]> reconstructPath(Node node) {
        List<int[]> path = new ArrayList<>();
        while (node != null) {
            path.add(new int[]{node.row, node.col});
            node = node.parent;
        }
        Collections.reverse(path); // Reverse to get path from start to end
        return path;
    }

    // Main function to test the algorithm
    public static void main(String[] args) {
        // Grid where 0 = walkable, 1 = obstacle
        int[][] grid = {
            {0, 0, 0, 0},
            {1, 1, 0, 1},
            {0, 0, 0, 0},
            {0, 1, 0, 0}
        };

        int[] start = {0, 0}; // Starting cell
        int[] end = {3, 2};   // Goal cell

        // Call A* algorithm and print the path
        List<int[]> path = aStar(grid, start, end);
        for (int[] p : path)
            System.out.println(Arrays.toString(p));
    }
}
